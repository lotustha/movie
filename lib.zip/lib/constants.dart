import 'package:flutter/material.dart';

const Color kBackgroundColor = Color(0xFF121212);
const Color kSurfaceColor = Color(0xFF1E1E1E);
const Color kPrimaryTextColor = Colors.white;
const Color kSecondaryTextColor = Colors.white70;
const Color kAccentColor = Colors.deepPurpleAccent;